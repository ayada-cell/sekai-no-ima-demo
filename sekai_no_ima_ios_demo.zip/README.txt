「世界のいま」iPhone/Android対応・体験版

このデータは【架空の写真・通知・お題】による操作デモです。
実際の会員登録・写真投稿・AI審査・Web Push・郵送・決済は行いません。

iOSで「押せない」となる場合、ChatGPTの添付HTMLプレビューではJavaScript操作が制限されている可能性があります。
Safariで正常に動かすには、HTTPSのWebサイトとして公開してください。

【GitHub Pagesで公開】
1. GitHubにログインし、新規のPublicリポジトリを「sekai-no-ima-demo」などの名前で作成。
   ※既存の看護ゲーム用リポジトリにはアップロードしないでください。
2. このフォルダ内の index.html を、新規リポジトリの一番上（ルート）にアップロードしてCommit。
3. リポジトリの Settings > Pages に移動。
4. Sourceを Deploy from a branch にし、Branch = main、Folder = /(root) を選んでSave。
5. GitHub Pagesの公開URL（一般に https://<ユーザー名>.github.io/sekai-no-ima-demo/ ）をiPhoneのSafariで開いて操作します。URLは実際のPages設定画面で確認してください。

注意：GitHub Pagesは公開サイトです。実ユーザーの顔・住所・個人データやAPIキーを絶対に置かないでください。
このフォルダのデモだけならダミーデータなので掲載可能です。

なお、このHTMLはローカルで開いても動くことがありますが、iOS側のファイルプレビューの制限は修正できません。
